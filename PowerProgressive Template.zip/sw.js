// Install happens when the app is used for the first time, or when a
// new version of the SW is detected by the browser.
// In the latter case, the old SW is kept around until the new one is
// activated by a new client.
self.addEventListener("install", event => {

});

// Activate happens after install, either when the app is used for the
// first time, or when a new version of the SW was installed.
self.addEventListener("activate", event => {

});

// Main fetch handler.
self.addEventListener("fetch", event => {

});